// RPI测评系统 - 主要JavaScript逻辑

// 题目数据
const QUESTIONS = [
    { id: 1, text: "我会希望伴侣每天主动跟我报备行程和接触的人", dimension: "控制欲望", type: "正向" },
    { id: 2, text: "看到伴侣和异性朋友单独吃饭或聊天，我会感到不舒服", dimension: "嫉妒强度", type: "正向" },
    { id: 3, text: "如果伴侣超过半天没回我消息，我会频繁翻看手机、胡思乱想", dimension: "情感依赖", type: "正向" },
    { id: 4, text: "我总是担心伴侣会因为遇到更优秀的人而离开我", dimension: "关系不安全感", type: "正向" },
    { id: 5, text: "我会下意识地查看伴侣的手机聊天记录或社交动态", dimension: "控制欲望", type: "正向" },
    { id: 6, text: "听到伴侣夸奖其他异性，我心里会莫名产生抵触情绪", dimension: "嫉妒强度", type: "正向" },
    { id: 7, text: "我做重要决定前，一定要先征求伴侣的意见才安心", dimension: "情感依赖", type: "正向" },
    { id: 8, text: "伴侣参加聚会没有带我，我会忍不住怀疑TA是不是有隐瞒", dimension: "关系不安全感", type: "正向" },
    { id: 9, text: "我希望伴侣的所有社交活动，都能提前让我知道并同意", dimension: "控制欲望", type: "正向" },
    { id: 10, text: "当伴侣对朋友的关注度超过我时，我会感到失落和不满", dimension: "嫉妒强度", type: "正向" },
    { id: 11, text: "没有伴侣的陪伴，我会觉得很多事情都没兴趣去做", dimension: "情感依赖", type: "正向" },
    { id: 12, text: "我总觉得伴侣身边的异性都对TA有好感，容易威胁到我们的关系", dimension: "关系不安全感", type: "正向" },
    { id: 13, text: "我会要求伴侣减少和我不喜欢的异性接触", dimension: "控制欲望", type: "正向" },
    { id: 14, text: "伴侣和前任保持联系，哪怕是普通问候，我也无法接受", dimension: "嫉妒强度", type: "正向" },
    { id: 15, text: "我习惯把每天的琐事都分享给伴侣，少了一次分享就会觉得不自在", dimension: "情感依赖", type: "正向" },
    { id: 16, text: "伴侣晚归时，我会反复追问TA的去向和同行人员，直到确认无误", dimension: "关系不安全感", type: "正向" },
    { id: 17, text: "我会干涉伴侣的穿搭风格，希望TA穿我喜欢的衣服出门", dimension: "控制欲望", type: "正向" },
    { id: 18, text: "看到伴侣给异性的社交动态点赞评论，我会追问他们的关系", dimension: "嫉妒强度", type: "正向" },
    { id: 19, text: "遇到困难时，我第一时间想到的就是向伴侣求助，自己很难独立解决", dimension: "情感依赖", type: "正向" },
    { id: 20, text: "我会害怕伴侣突然不喜欢我了，经常需要TA反复确认对我的感情", dimension: "关系不安全感", type: "正向" },
    { id: 21, text: "我希望伴侣的手机密码、社交账号密码都告诉我", dimension: "控制欲望", type: "正向" },
    { id: 22, text: "伴侣和异性朋友开玩笑过于亲密，我会当场表现出不高兴", dimension: "嫉妒强度", type: "正向" },
    { id: 23, text: "我会因为伴侣没及时关注我的情绪而感到被忽视，甚至生气", dimension: "情感依赖", type: "正向" },
    { id: 24, text: "我总觉得伴侣对我的感情不够真诚，需要不断验证", dimension: "关系不安全感", type: "正向" },
    { id: 25, text: "我会限制伴侣的娱乐时间，希望TA把更多时间花在我身上", dimension: "控制欲望", type: "反向" },
    { id: 26, text: "我能坦然接受伴侣有自己的异性好友，不会过度干涉他们的交往", dimension: "嫉妒强度", type: "反向" },
    { id: 27, text: "即使伴侣不在身边，我也能独立安排好自己的生活和娱乐", dimension: "情感依赖", type: "反向" },
    { id: 28, text: "我完全信任伴侣，不会因为外界的闲言碎语怀疑我们的关系", dimension: "关系不安全感", type: "反向" },
    { id: 29, text: "我不会强迫伴侣按照我的意愿做事，尊重TA的自主选择", dimension: "控制欲望", type: "反向" },
    { id: 30, text: "伴侣夸奖其他异性时，我会觉得TA有欣赏美的眼光，不会吃醋", dimension: "嫉妒强度", type: "反向" },
    { id: 31, text: "我有自己的兴趣爱好和社交圈，不需要时刻依赖伴侣的陪伴", dimension: "情感依赖", type: "反向" },
    { id: 32, text: "伴侣参加集体活动不带我，我会觉得TA需要自己的空间，不会多想", dimension: "关系不安全感", type: "反向" },
    { id: 33, text: "我不会主动查看伴侣的隐私，认为亲密关系也需要保留个人空间", dimension: "控制欲望", type: "反向" },
    { id: 34, text: "伴侣和前任保持礼貌的距离，我觉得这是正常的，不会介意", dimension: "嫉妒强度", type: "反向" },
    { id: 35, text: "我能自己消化负面情绪，不会把所有情绪压力都转移给伴侣", dimension: "情感依赖", type: "反向" },
    { id: 36, text: "我相信自己足够优秀，不会担心伴侣因为别人而离开我", dimension: "关系不安全感", type: "反向" },
    { id: 37, text: "我会支持伴侣发展自己的事业或爱好，不会因为占用相处时间而抱怨", dimension: "控制欲望", type: "正向" },
    { id: 38, text: "看到伴侣和异性一起合照，我会忍不住问清楚合照的场景和原因", dimension: "嫉妒强度", type: "正向" },
    { id: 39, text: "我会把伴侣的需求放在第一位，优先满足TA的想法而忽略自己的", dimension: "情感依赖", type: "正向" },
    { id: 40, text: "伴侣和我产生分歧时，我会担心这是我们感情破裂的开始", dimension: "关系不安全感", type: "正向" },
    { id: 41, text: "我会希望伴侣主动向身边人公开我们的关系，避免产生误会", dimension: "控制欲望", type: "正向" },
    { id: 42, text: "伴侣收到异性送的礼物，我会详细询问礼物的来源和意义", dimension: "嫉妒强度", type: "正向" },
    { id: 43, text: "我会因为伴侣忘记我们的纪念日而感到极度失落，觉得TA不够在乎我", dimension: "情感依赖", type: "正向" },
    { id: 44, text: "我总担心伴侣在我看不到的地方做对不起我的事", dimension: "关系不安全感", type: "正向" },
    { id: 45, text: "我不会因为自己的情绪不好，就要求伴侣随时陪伴在身边", dimension: "情感依赖", type: "反向" },
    { id: 46, text: "我能接受伴侣有不跟我分享的小秘密，不会强行追问", dimension: "控制欲望", type: "反向" },
    { id: 47, text: "即使伴侣和异性有工作上的频繁接触，我也相信TA能把握好边界", dimension: "嫉妒强度", type: "反向" },
    { id: 48, text: "我不会因为伴侣偶尔的疏忽，就否定TA对我的感情", dimension: "关系不安全感", type: "反向" },
    { id: 49, text: "我会鼓励伴侣多交新朋友，包括异性朋友，认为这能让TA更开心", dimension: "控制欲望", type: "反向" },
    { id: 50, text: "我对我们的关系充满信心，相信我们能一起应对各种挑战", dimension: "关系不安全感", type: "反向" }
];

// 维度配置（20题版本）
const DIMENSIONS = {
    "控制欲望": {
        name: "控制欲望",
        maxScore: 25,
        ranges: {
            low: { min: 0, max: 8, title: "自主型", desc: "您给予伴侣充分的自由空间，尊重对方的独立性" },
            medium: { min: 9, max: 16, title: "平衡型", desc: "您在亲密关系中追求适度的了解和控制" },
            high: { min: 17, max: 25, title: "控制型", desc: "您在亲密关系中表现出较强的控制欲望" }
        }
    },
    "嫉妒强度": {
        name: "嫉妒强度",
        maxScore: 25,
        ranges: {
            low: { min: 0, max: 8, title: "自信型", desc: "您对自身魅力和关系稳定性很有信心" },
            medium: { min: 9, max: 16, title: "正常型", desc: "您在亲密关系中表现出适度的关注和在乎" },
            high: { min: 17, max: 25, title: "敏感型", desc: "您在亲密关系中表现出较强的嫉妒倾向" }
        }
    },
    "情感依赖": {
        name: "情感依赖",
        maxScore: 25,
        ranges: {
            low: { min: 0, max: 8, title: "独立型", desc: "您在情感上较为独立，能自主处理各种情况" },
            medium: { min: 9, max: 16, title: "适中型", desc: "您在亲密关系中既保持独立又适度依赖" },
            high: { min: 17, max: 25, title: "依赖型", desc: "您在情感上表现出较强的依赖倾向" }
        }
    },
    "关系不安全感": {
        name: "关系不安全感",
        maxScore: 25,
        ranges: {
            low: { min: 0, max: 8, title: "安全型", desc: "您对亲密关系充满信心，很少产生担忧" },
            medium: { min: 9, max: 16, title: "稳重型", desc: "您对关系有适度的关注和担心" },
            high: { min: 17, max: 25, title: "焦虑型", desc: "您对亲密关系表现出较强的焦虑和不安全感" }
        }
    }
};

// 改进建议配置
const IMPROVEMENT_SUGGESTIONS = {
    "控制欲望": {
        low: {
            title: "继续保持良好的空间感",
            suggestions: [
                "保持对伴侣的信任和尊重，这是健康关系的基础",
                "鼓励伴侣发展自己的兴趣和社交圈",
                "当伴侣需要独处时，给予支持和理解"
            ]
        },
        medium: {
            title: "适度调整控制欲",
            suggestions: [
                "学会区分\"合理关心\"和\"过度控制\"",
                "尝试与伴侣开放沟通，了解彼此的界限需求",
                "当感到不安时，先思考是否源于自身的不安全感"
            ]
        },
        high: {
            title: "减少控制欲，增强信任",
            suggestions: [
                "学会尊重伴侣的个人空间和隐私",
                "培养对关系的信任感，减少无端的猜疑",
                "将注意力转移到个人兴趣和成长上",
                "必要时考虑寻求专业心理咨询帮助"
            ]
        }
    },
    "嫉妒强度": {
        low: {
            title: "保持健康的自信状态",
            suggestions: [
                "继续保持对自身魅力的信心",
                "在关系中保持适度的醋意，可以增进亲密度",
                "支持伴侣的正常社交，避免过度冷漠"
            ]
        },
        medium: {
            title: "平衡关注度和信任度",
            suggestions: [
                "当感到嫉妒时，先尝试理性分析原因",
                "与伴侣开诚布公地讨论彼此的界限",
                "培养独立性，减少对伴侣行为的过度关注"
            ]
        },
        high: {
            title: "增强自信，降低嫉妒情绪",
            suggestions: [
                "发展个人兴趣爱好，提升自我价值感",
                "学会信任伴侣，减少对关系的过度监控",
                "练习正念冥想，学会处理负面情绪",
                "必要时寻求专业帮助，学习情绪管理技巧"
            ]
        }
    },
    "情感依赖": {
        low: {
            title: "保持健康的独立性",
            suggestions: [
                "继续保持个人兴趣爱好和社交生活",
                "在亲密关系中保持适度的独立空间",
                "培养解决问题的能力，不过度依赖他人建议"
            ]
        },
        medium: {
            title: "平衡独立与依赖",
            suggestions: [
                "学会在需要时寻求支持，但不过度依赖",
                "培养处理负面情绪的独立能力",
                "练习做决策时既考虑伴侣意见，也尊重自己的判断"
            ]
        },
        high: {
            title: "增强情感独立性",
            suggestions: [
                "培养个人兴趣爱好，减少对伴侣的过度依赖",
                "学会独立处理情绪和问题，不立即寻求安慰",
                "建立支持网络，包括朋友、家人和专业帮助",
                "练习正念和自我反思，增强自我认知"
            ]
        }
    },
    "关系不安全感": {
        low: {
            title: "维持健康的信任关系",
            suggestions: [
                "继续保持对关系的信心和信任",
                "当出现疑虑时，理性分析而非过度担忧",
                "在关系中保持适度的警觉性，有助于维护关系健康"
            ]
        },
        medium: {
            title: "平衡关注与信任",
            suggestions: [
                "学会区分合理的关注和过度的担忧",
                "与伴侣开诚布公地沟通，建立更深的信任",
                "当感到不安时，尝试直接表达而非暗自猜测"
            ]
        },
        high: {
            title: "增强关系安全感",
            suggestions: [
                "学习沟通技巧，开放地表达担忧和需求",
                "通过自我提升增强自信心，减少对关系的焦虑",
                "练习正念冥想，学会接纳不确定性",
                "必要时寻求专业关系咨询师的帮助"
            ]
        }
    }
};

// 全局变量
let currentQuestionIndex = 0;
let answers = {};
let userAnswers = [];
let selectedQuestions = []; // 存储随机选择的20道题目

// 页面初始化
// 页面初始化
function initPage() {
    console.log('开始初始化页面...');
    console.log('页面body class:', document.body.className);
    console.log('当前URL:', window.location.href);
    
    const body = document.body;
    
    if (body.classList.contains('test-page')) {
        console.log('检测到测试页面，开始初始化...');
        initTestPage();
    } else if (body.classList.contains('result-page')) {
        console.log('检测到结果页面，开始初始化...');
        initResultPage();
    } else {
        console.log('检测到首页，开始初始化...');
        initHomePage();
    }
}

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', initPage);

// 兼容老版本
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPage);
} else {
    console.log('DOM已加载，直接初始化');
    initPage();
}

// 首页初始化
function initHomePage() {
    console.log('首页初始化完成');
}

// 随机选择20道题目
function selectRandomQuestions() {
    const questionsPerDimension = 5; // 每个维度选择5题
    
    // 按维度分组题目
    const dimensionGroups = {
        "控制欲望": [],
        "嫉妒强度": [],
        "情感依赖": [],
        "关系不安全感": []
    };
    
    QUESTIONS.forEach(question => {
        dimensionGroups[question.dimension].push(question);
    });
    
    // 从每个维度随机选择5题
    const selected = [];
    Object.keys(dimensionGroups).forEach(dimension => {
        const dimensionQuestions = dimensionGroups[dimension];
        // 打乱数组
        const shuffled = dimensionQuestions.sort(() => Math.random() - 0.5);
        // 选择前5题
        selected.push(...shuffled.slice(0, questionsPerDimension));
    });
    
    // 随机打乱最终结果
    return selected.sort(() => Math.random() - 0.5);
}

// 答题页面初始化
function initTestPage() {
    // 如果没有保存的题目，随机生成20题
    const savedQuestions = localStorage.getItem('rpiSelectedQuestions');
    if (savedQuestions) {
        selectedQuestions = JSON.parse(savedQuestions);
    } else {
        selectedQuestions = selectRandomQuestions();
        localStorage.setItem('rpiSelectedQuestions', JSON.stringify(selectedQuestions));
    }
    
    loadProgress();
    renderQuestion();
    updateProgress();
    
    // 绑定导航按钮
    document.getElementById('prevBtn').addEventListener('click', previousQuestion);
    document.getElementById('nextBtn').addEventListener('click', nextQuestion);
}

// 渲染题目
function renderQuestion() {
    const question = selectedQuestions[currentQuestionIndex];
    const container = document.getElementById('questionContainer');
    
    container.innerHTML = `
        <div class="question-number">题目 ${currentQuestionIndex + 1} / ${selectedQuestions.length}</div>
        <div class="question-text">${question.text}</div>
        <div class="options">
            ${generateOptions(question)}
        </div>
    `;
    
    // 绑定选项事件
    const options = container.querySelectorAll('.option');
    options.forEach(option => {
        option.addEventListener('click', function() {
            selectOption(parseInt(this.dataset.value));
        });
    });
    
    // 恢复之前的选择
    if (answers[question.id]) {
        const selectedOption = container.querySelector(`[data-value="${answers[question.id]}"]`);
        if (selectedOption) {
            selectedOption.classList.add('selected');
        }
    }
    
    updateNavigationButtons();
}

// 生成选项
function generateOptions(question) {
    const labels = ['完全不符合', '不太符合', '一般', '比较符合', '完全符合'];
    return labels.map((label, index) => `
        <div class="option" data-value="${index + 1}">
            <span class="option-value">${index + 1}</span>
            <span class="option-label">${label}</span>
        </div>
    `).join('');
}

// 选择选项
function selectOption(value) {
    const question = selectedQuestions[currentQuestionIndex];
    answers[question.id] = value;
    userAnswers[currentQuestionIndex] = value;
    
    // 更新UI
    const options = document.querySelectorAll('.option');
    options.forEach(option => option.classList.remove('selected'));
    document.querySelector(`[data-value="${value}"]`).classList.add('selected');
    
    // 保存进度
    saveProgress();
    
    updateNavigationButtons();
}

// 更新进度条
function updateProgress() {
    const progress = ((currentQuestionIndex + 1) / selectedQuestions.length) * 100;
    document.getElementById('progressFill').style.width = progress + '%';
    document.getElementById('progressText').textContent = `${currentQuestionIndex + 1} / ${selectedQuestions.length}`;
}

// 更新导航按钮
function updateNavigationButtons() {
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    prevBtn.disabled = currentQuestionIndex === 0;
    
    if (currentQuestionIndex === selectedQuestions.length - 1) {
        nextBtn.textContent = '查看结果';
        nextBtn.onclick = calculateResults;
    } else {
        nextBtn.textContent = '下一题';
        nextBtn.onclick = nextQuestion;
    }
}

// 上一题
function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        renderQuestion();
        updateProgress();
        updateNavigationButtons();
    }
}

// 下一题
function nextQuestion() {
    if (currentQuestionIndex < selectedQuestions.length - 1) {
        currentQuestionIndex++;
        renderQuestion();
        updateProgress();
        updateNavigationButtons();
    }
}

// 计算结果
function calculateResults() {
    const results = calculateScores();
    localStorage.setItem('rpiResults', JSON.stringify(results));
    window.location.href = 'result.html';
}

// 计算得分
function calculateScores() {
    const dimensionScores = {
        "控制欲望": 0,
        "嫉妒强度": 0,
        "情感依赖": 0,
        "关系不安全感": 0
    };
    
    selectedQuestions.forEach(question => {
        const answer = answers[question.id];
        if (answer) {
            const score = question.type === '正向' ? answer : 6 - answer;
            dimensionScores[question.dimension] += score;
        }
    });
    
    // 计算总体得分
    const totalScore = Object.values(dimensionScores).reduce((sum, score) => sum + score, 0);
    const maxTotalScore = Object.values(DIMENSIONS).reduce((sum, dim) => sum + dim.maxScore, 0);
    const overallPercentage = Math.round((totalScore / maxTotalScore) * 100);
    
    return {
        overallScore: totalScore,
        overallPercentage: overallPercentage,
        dimensionScores: dimensionScores,
        selectedQuestions: selectedQuestions.length, // 添加题目数量信息
        timestamp: new Date().toISOString()
    };
}

// 保存进度
function saveProgress() {
    const progress = {
        currentQuestionIndex,
        answers,
        userAnswers,
        timestamp: Date.now()
    };
    localStorage.setItem('rpiProgress', JSON.stringify(progress));
}

// 加载进度
function loadProgress() {
    const saved = localStorage.getItem('rpiProgress');
    if (saved) {
        try {
            const progress = JSON.parse(saved);
            // 检查是否超过24小时
            if (Date.now() - progress.timestamp < 24 * 60 * 60 * 1000) {
                currentQuestionIndex = progress.currentQuestionIndex || 0;
                answers = progress.answers || {};
                userAnswers = progress.userAnswers || [];
            }
        } catch (e) {
            console.log('加载进度失败，使用默认设置');
        }
    }
}

// 结果页面初始化
function initResultPage() {
    const results = JSON.parse(localStorage.getItem('rpiResults'));
    if (!results) {
        window.location.href = 'index.html';
        return;
    }
    
    displayResults(results);
    drawRadarChart(results);
    displayDimensionDetails(results);
    
    // 绑定重新测试按钮
    document.getElementById('restartBtn').addEventListener('click', restartTest);
}

// 显示结果
function displayResults(results) {
    document.getElementById('overallScore').textContent = results.overallScore;
    document.getElementById('overallPercentage').textContent = results.overallPercentage;
    displayDimensionDetails(results);
    displayImprovementSuggestions(results);
}

// 绘制雷达图
function drawRadarChart(results) {
    const ctx = document.getElementById('radarChart').getContext('2d');
    
    const data = {
        labels: ['控制欲望', '嫉妒强度', '情感依赖', '关系不安全感'],
        datasets: [{
            label: '您的得分',
            data: [
                results.dimensionScores["控制欲望"],
                results.dimensionScores["嫉妒强度"],
                results.dimensionScores["情感依赖"],
                results.dimensionScores["关系不安全感"]
            ],
            backgroundColor: 'rgba(233, 30, 99, 0.2)',
            borderColor: '#e91e63',
            borderWidth: 2,
            pointBackgroundColor: '#e91e63',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 6
        }]
    };
    
    const config = {
        type: 'radar',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 25,
                    ticks: {
                        stepSize: 5
                    },
                    grid: {
                        color: '#f0f0f0'
                    },
                    pointLabels: {
                        font: {
                            size: 14,
                            weight: 'bold'
                        },
                        color: '#333'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    };
    
    new Chart(ctx, config);
}

// 显示维度详情
function displayDimensionDetails(results) {
    const container = document.getElementById('dimensionResults');
    container.innerHTML = '';
    
    Object.keys(DIMENSIONS).forEach(dimensionName => {
        const score = results.dimensionScores[dimensionName];
        const config = DIMENSIONS[dimensionName];
        const range = getScoreRange(score, config.ranges);
        
        const card = document.createElement('div');
        card.className = 'dimension-card';
        card.innerHTML = `
            <h3>${config.name}</h3>
            <div class="dimension-score">${score} / ${config.maxScore}</div>
            <div class="dimension-level">${range.title}</div>
            <p>${range.desc}</p>
        `;
        
        container.appendChild(card);
    });
}

// 获取得分区间
function getScoreRange(score, ranges) {
    for (const [level, range] of Object.entries(ranges)) {
        if (score >= range.min && score <= range.max) {
            return range;
        }
    }
    return ranges.medium;
}

// 获取建议级别
function getSuggestionLevel(score, ranges) {
    for (const [level, range] of Object.entries(ranges)) {
        if (score >= range.min && score <= range.max) {
            return level;
        }
    }
    return 'medium';
}

// 显示改进建议
function displayImprovementSuggestions(results) {
    const container = document.getElementById('improvementSuggestions');
    if (!container) return;
    
    // 找出得分最高的维度（最需要改进的方面）
    const dimensionScores = results.dimensionScores;
    const sortedDimensions = Object.keys(dimensionScores).sort((a, b) => 
        dimensionScores[b] - dimensionScores[a]
    );
    
    // 生成HTML
    let html = `
        <h2 style="text-align: center; margin: 30px 0; color: #e91e63;">改进建议</h2>
        <div class="suggestions-container">
    `;
    
    // 为每个维度显示建议，但按得分高低排序
    sortedDimensions.forEach(dimensionName => {
        const score = dimensionScores[dimensionName];
        const config = DIMENSIONS[dimensionName];
        const range = getScoreRange(score, config.ranges);
        const level = getSuggestionLevel(score, config.ranges);
        const suggestions = IMPROVEMENT_SUGGESTIONS[dimensionName][level];
        
        html += `
            <div class="suggestion-card">
                <h3 class="suggestion-title">${config.name} - ${range.title}</h3>
                <div class="suggestion-level" style="text-align: center; margin-bottom: 10px;">
                    <span class="level-badge level-${level}">${range.title}</span>
                </div>
                <div class="suggestion-content">
                    <h4 class="suggestion-subtitle">${suggestions.title}</h4>
                    <ul class="suggestion-list">
                        ${suggestions.suggestions.map(suggestion => 
                            `<li>${suggestion}</li>`
                        ).join('')}
                    </ul>
                </div>
            </div>
        `;
    });
    
    html += `
        </div>
        <div class="suggestion-footer">
            <p style="text-align: center; color: #666; font-style: italic; margin-top: 20px;">
                建议仅供参巧，培养健康的关系需要双方的共同努力和持续沟通。
            </p>
        </div>
    `;
    
    container.innerHTML = html;
}

// 重新开始测试
function restartTest() {
    localStorage.removeItem('rpiProgress');
    localStorage.removeItem('rpiResults');
    localStorage.removeItem('rpiSelectedQuestions');
    window.location.href = 'index.html';
}